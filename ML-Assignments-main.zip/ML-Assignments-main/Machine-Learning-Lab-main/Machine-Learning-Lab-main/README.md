# Machine-Learning-Lab
This is a file that contains all the 7 assignments of Machine Learning Lab
